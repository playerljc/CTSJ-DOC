import IframeDemo from './iframe_demo';

export default [
  {
    title: 'Iframe_Demo',
    keyword: 'Iframe_Demo',
    component: (h) => h(IframeDemo),
  },
];
