export default ['海量智搜'];
