import React from 'react';

import Map3D from './3d';

export default [
  {
    title: '3D',
    keyword: '3D',
    component: <Map3D />,
  },
];
