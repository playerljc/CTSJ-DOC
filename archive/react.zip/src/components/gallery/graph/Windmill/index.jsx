import Windmill from './Windmill';

export default Windmill;
