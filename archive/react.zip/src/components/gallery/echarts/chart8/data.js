const data = [
  {
    value: 12,
    name: 'G2Plot',
  },
  {
    value: 9,
    name: 'AntV',
  },
  {
    value: 8,
    name: 'F2',
  },
  {
    value: 8,
    name: 'G2',
  },
  {
    value: 8,
    name: 'G6',
  },
  {
    value: 8,
    name: 'DataSet',
  },
  {
    value: 8,
    name: '墨者学院',
  },
  {
    value: 6,
    name: 'Analysis',
  },
  {
    value: 6,
    name: 'Data Mining',
  },
  {
    value: 6,
    name: 'Data Vis',
  },
  {
    value: 3,
    name: 'sort',
  },
  {
    value: 3,
    name: 'Subset',
  },

  {
    value: 2,
    name: '祯逸',
  },
  {
    value: 2,
    name: '绝云',
  },
  {
    value: 2,
    name: '罗宪',
  },
  {
    value: 2,
    name: '萧庆',
  },
  {
    value: 2,
    name: '哦豁',
  },
  {
    value: 2,
    name: '逍为',
  },
  {
    value: 2,
    name: '翎刀',
  },
  {
    value: 2,
    name: '陆沉',
  },
  {
    value: 2,
    name: '顾倾',
  },
  {
    value: 2,
    name: 'Domo',
  },
  {
    value: 2,
    name: 'GPL',
  },
  {
    value: 2,
    name: 'PAI',
  },
  {
    value: 2,
    name: 'SPSS',
  },
  {
    value: 2,
    name: 'SYSTAT',
  },
  {
    value: 2,
    name: 'Tableau',
  },
  {
    value: 2,
    name: 'D3',
  },
  {
    value: 2,
    name: 'Vega',
  },
  {
    value: 2,
    name: '统计图表',
  },
];

export default data;
