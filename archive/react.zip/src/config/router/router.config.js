import React from 'react';

import BasicLayout from '@/lib/BasicLayout';

import Components from '@/config/router/routerComponentRegister';

const {
  App,
  Introduction,
  Changelog,
  Split,
  Space,
  ConditionalRender,
  DelConfirm,
  ImportantConfirm,
  GlobalIndicator,
  Spin,
  HistoryBack,
  SuccessPrompt,
  ErrorPrompt,
  WarnPrompt,
  ImageLazy,
  MessageDialog,
  Permission,
  Suspense,
  TableHeadSearch,
  CSS,
  OLMap,
  FlexLayout,
  SplitLayout,
  StickupLayout,
  Surnames,
  SliderScale,
  Revolving,
  ScrollLoad,
  JDCategoryTab,
  CascadeCompared,
  SlideLayout,
  ContextMenu,
  FontSizeSetting,
  SearchTable,
  FormItemCreator,
  TableList,
  Popup,
  BackTopAnimation,
  PullRefresh,
  Notification,
  SwipeOut,
  PolygonSelection,
  PlayGround,
  BMap,
  Hooks,
  AdapterScreen,
  Decorators,
  Dict,
  Emitter,
  Preferences,
  Intl,
  NotNull,
  Util,
  WatchMemoized,
  Ajax,
  Domain,
  Resource,
  Browsersniff,
  Validator,
  ReactUtil,
  Echarts,
  Demo,
} = Components;

export default () => [
  {
    path: '/',
    component: App,
    routes: [
      {
        path: '/',
        redirect: '/adhere/introduction',
      },
      {
        path: '/adhere/introduction',
        name: '简介',
        component: Introduction,
      },
      {
        path: '/adhere/changelog',
        name: '更新日志',
        component: Changelog,
      },
      {
        path: '/adhere/gallery',
        component: BasicLayout,
        routes: [
          {
            path: '/',
            redirect: '/adhere/gallery/echarts',
          },
          {
            path: '/adhere/gallery/echarts',
            name: 'Echarts',
            component: Echarts,
          },
        ],
      },
      {
        path: '/adhere/component',
        component: BasicLayout,
        routes: [
          {
            path: '/',
            redirect: '/adhere/component/ui',
          },
          {
            path: '/adhere/component/ui',
            name: 'UI',
            routes: [
              {
                path: '/',
                redirect: '/adhere/component/ui/split',
              },
              {
                path: '/adhere/component/ui/demo',
                name: 'Demo',
                component: Demo,
              },
              {
                path: '/adhere/component/ui/split',
                name: 'Split',
                component: Split,
              },
              {
                path: '/adhere/component/ui/space',
                name: 'Space',
                component: Space,
              },
              {
                path: '/adhere/component/ui/conditionalrender',
                name: 'ConditionalRender',
                component: ConditionalRender,
              },
              {
                path: '/adhere/component/ui/delconfirm',
                name: 'DelConfirm',
                component: DelConfirm,
              },
              {
                path: '/adhere/component/ui/importantconfirm',
                name: 'ImportantConfirm',
                component: ImportantConfirm,
              },
              {
                path: '/adhere/component/ui/globalindicator',
                name: 'GlobalIndicator',
                component: GlobalIndicator,
              },
              {
                path: '/adhere/component/ui/spin',
                name: 'Spin',
                component: Spin,
              },
              {
                path: '/adhere/component/ui/historyback',
                name: 'HistoryBack',
                component: HistoryBack,
              },
              {
                path: '/adhere/component/ui/successprompt',
                name: 'SuccessPrompt',
                component: SuccessPrompt,
              },
              {
                path: '/adhere/component/ui/errorprompt',
                name: 'ErrorPrompt',
                component: ErrorPrompt,
              },
              {
                path: '/adhere/component/ui/warnprompt',
                name: 'WarnPrompt',
                component: WarnPrompt,
              },
              {
                path: '/adhere/component/ui/imagelazy',
                name: 'ImageLazy',
                component: ImageLazy,
              },
              {
                path: '/adhere/component/ui/messagedialog',
                name: 'MessageDialog',
                component: MessageDialog,
              },
              {
                path: '/adhere/component/ui/permission',
                name: 'Permission',
                component: Permission,
              },
              {
                path: '/adhere/component/ui/suspense',
                name: 'Suspense',
                component: Suspense,
              },
              {
                path: '/adhere/component/ui/tableheadsearch',
                name: 'TableHeadSearch',
                component: TableHeadSearch,
              },
              {
                path: '/adhere/component/ui/css',
                name: 'CSS',
                component: CSS,
              },
              {
                path: '/adhere/component/ui/olmap',
                name: 'OLMap',
                component: OLMap,
              },
              {
                path: '/adhere/component/ui/flexlayout',
                name: 'FlexLayout',
                component: FlexLayout,
              },
              {
                path: '/adhere/component/ui/splitlayout',
                name: 'SplitLayout',
                component: SplitLayout,
              },
              {
                path: '/adhere/component/ui/stickuplayout',
                name: 'StickupLayout',
                component: StickupLayout,
              },
              {
                path: '/adhere/component/ui/surnames',
                name: 'Surnames',
                component: Surnames,
              },
              {
                path: '/adhere/component/ui/sliderscale',
                name: 'SliderScale',
                component: SliderScale,
              },
              {
                path: '/adhere/component/ui/revolving',
                name: 'Revolving',
                component: Revolving,
              },
              {
                path: '/adhere/component/ui/scrollload',
                name: 'ScrollLoad',
                component: ScrollLoad,
              },
              {
                path: '/adhere/component/ui/jdcategorytab',
                name: 'JDCategoryTab',
                component: JDCategoryTab,
              },
              {
                path: '/adhere/component/ui/cascadecompared',
                name: 'CascadeCompared',
                component: CascadeCompared,
              },
              {
                path: '/adhere/component/ui/slidelayout',
                name: 'SlideLayout',
                component: SlideLayout,
              },
              {
                path: '/adhere/component/ui/contextmenu',
                name: 'ContextMenu',
                component: ContextMenu,
              },
              {
                path: '/adhere/component/ui/fontsizesetting',
                name: 'FontSizeSetting',
                component: FontSizeSetting,
              },
              {
                path: '/adhere/component/ui/searchtable',
                name: 'SearchTable',
                component: SearchTable,
              },
              {
                path: '/adhere/component/ui/formitemcreator',
                name: 'FormItemCreator',
                component: FormItemCreator,
              },
              {
                path: '/adhere/component/ui/tablelist',
                name: 'TableList',
                component: TableList,
              },
              {
                path: '/adhere/component/ui/popup',
                name: 'Popup',
                component: Popup,
              },
              {
                path: '/adhere/component/ui/backtopanimation',
                name: 'BackTopAnimation',
                component: BackTopAnimation,
              },
              {
                path: '/adhere/component/ui/pullrefresh',
                name: 'PullRefresh',
                component: PullRefresh,
              },
              {
                path: '/adhere/component/ui/notification',
                name: 'Notification',
                component: Notification,
              },
              {
                path: '/adhere/component/ui/swipeout',
                name: 'SwipeOut',
                component: SwipeOut,
              },
              {
                path: '/adhere/component/ui/polygonselection',
                name: 'PolygonSelection',
                component: PolygonSelection,
              },
              {
                path: '/adhere/component/ui/playground',
                name: 'PlayGround',
                component: PlayGround,
              },
              {
                path: '/adhere/component/ui/hooks',
                name: 'Hooks',
                component: Hooks,
              },
            ],
          },
          {
            path: '/adhere/component/util',
            name: 'Util',
            routes: [
              {
                path: '/',
                redirect: '/adhere/component/util/adapterscreen',
              },
              {
                path: '/adhere/component/util/adapterscreen',
                name: 'AdapterScreen',
                component: AdapterScreen,
              },
              {
                path: '/adhere/component/util/decorators',
                name: 'Decorators',
                component: Decorators,
              },
              {
                path: '/adhere/component/util/dict',
                name: 'Dict',
                component: Dict,
              },
              {
                path: '/adhere/component/util/emitter',
                name: 'Emitter',
                component: Emitter,
              },
              {
                path: '/adhere/component/util/preferences',
                name: 'Preferences',
                component: Preferences,
              },
              {
                path: '/adhere/component/util/intl',
                name: 'Intl',
                component: Intl,
              },
              {
                path: '/adhere/component/util/notnull',
                name: 'NotNull',
                component: NotNull,
              },
              {
                path: '/adhere/component/util/util',
                name: 'Util',
                component: Util,
              },
              {
                path: '/adhere/component/util/watchmemoized',
                name: 'WatchMemoized',
                component: WatchMemoized,
              },
              {
                path: '/adhere/component/util/ajax',
                name: 'Ajax',
                component: Ajax,
              },
              {
                path: '/adhere/component/util/domain',
                name: 'Domain',
                component: Domain,
              },
              {
                path: '/adhere/component/util/resource',
                name: 'Resource',
                component: Resource,
              },
              {
                path: '/adhere/component/util/browsersniff',
                name: 'Browsersniff',
                component: Browsersniff,
              },
              {
                path: '/adhere/component/util/validator',
                name: 'Validator',
                component: Validator,
              },
              {
                path: '/adhere/component/util/reactutil',
                name: 'ReactUtil',
                component: ReactUtil,
              },
            ],
          },
        ],
      },
    ],
  },
];
